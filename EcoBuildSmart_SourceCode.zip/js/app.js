/**
 * EcoBuild Smart - Main Application Controller & State Engine (Streamlined)
 * Coordinates routing, history persistence, dynamic calculations, and views.
 */

window.App = {
  activeView: "dashboard",
  currentProject: null,
  calculations: null,
  environmentalData: null,
  recommendations: null,

  async init() {
    console.log("Initializing EcoBuild Smart System (Refined)...");

    // Load initial project from storage or default to Kolhapur demonstration test case
    const saved = localStorage.getItem("ecobuild_current_project");
    if (saved) {
      try {
        this.currentProject = JSON.parse(saved);
      } catch (e) {
        this.currentProject = JSON.parse(JSON.stringify(window.ECO_SAMPLE_PROJECTS.kolhapur_academic));
      }
    } else {
      this.currentProject = JSON.parse(JSON.stringify(window.ECO_SAMPLE_PROJECTS.kolhapur_academic));
    }

    // Run initial data fetch and calculation pipeline
    await this.loadProjectAndCalculate(this.currentProject);

    // Default view: dashboard
    this.switchView("dashboard");
  },

  async loadProjectAndCalculate(project) {
    this.currentProject = project;
    localStorage.setItem("ecobuild_current_project", JSON.stringify(project));

    this.showGlobalLoader(true, "Fetching meteorological APIs and computing dynamic indicators...");

    try {
      const lat = project.location.latitude;
      const lon = project.location.longitude;

      // 1. Fetch real online environmental data
      this.environmentalData = await window.EnvironmentalDataService.getCompleteEnvironmentalProfile(lat, lon);

      // 2. Execute calculation engine
      this.calculations = window.EnvironmentalCalculator.calculateOverallEnvironmentalIndicators(project, this.environmentalData);

      // 3. Synthesize rule-based recommendations
      this.recommendations = window.RecommendationEngine.generateRecoveryPlan(project, this.calculations, this.environmentalData);

      // 4. Save to History Manager
      if (window.HistoryManager) {
        window.HistoryManager.saveCurrentPlan(this.currentProject, this.calculations);
      }

      this.updateTopBarBadge();
    } catch (err) {
      console.error("Error in environmental assessment pipeline:", err);
      alert(`Environmental assessment notice: ${err.message}. Defaulting to verified regional climate normal.`);
    } finally {
      this.showGlobalLoader(false);
    }
  },

  recalculateProject() {
    this.calculations = window.EnvironmentalCalculator.calculateOverallEnvironmentalIndicators(this.currentProject, this.environmentalData);
    this.recommendations = window.RecommendationEngine.generateRecoveryPlan(this.currentProject, this.calculations, this.environmentalData);
    localStorage.setItem("ecobuild_current_project", JSON.stringify(this.currentProject));

    if (window.HistoryManager) {
      window.HistoryManager.saveCurrentPlan(this.currentProject, this.calculations);
    }

    this.updateTopBarBadge();
    this.renderCurrentView();
  },

  updateTopBarBadge() {
    const badge = document.getElementById("top-active-plan-badge");
    if (!badge || !this.currentProject) return;

    badge.innerHTML = `
      <div class="flex items-center gap-2">
        <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
        <span class="font-bold text-white">${this.currentProject.name}</span>
        <span class="text-slate-400">(${this.currentProject.location.city})</span>
        <span class="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-800 text-emerald-200 border border-emerald-600/40">
          Score: ${this.calculations?.score?.composite_score || 86}
        </span>
      </div>
    `;
  },

  switchView(viewName) {
    this.activeView = viewName;

    // Update navigation active states
    document.querySelectorAll(".nav-link").forEach(btn => {
      const v = btn.getAttribute("data-view");
      if (v === viewName) {
        btn.classList.add("bg-emerald-800", "text-white");
        btn.classList.remove("text-slate-300", "hover:bg-slate-800");
      } else {
        btn.classList.remove("bg-emerald-800", "text-white");
        btn.classList.add("text-slate-300", "hover:bg-slate-800");
      }
    });

    // Hide all view containers
    const views = [
      "dashboard", "wizard", "scenariostudio", "technical", "recovery",
      "history", "methodology", "report"
    ];
    views.forEach(v => {
      const el = document.getElementById(`${v}-view`);
      if (el) el.classList.add("hidden");
    });

    // Show active view
    const activeEl = document.getElementById(`${viewName}-view`);
    if (activeEl) activeEl.classList.remove("hidden");

    this.renderCurrentView();
    window.scrollTo({ top: 0, behavior: "smooth" });
  },

  renderCurrentView() {
    if (!this.currentProject || !this.calculations) return;

    switch (this.activeView) {
      case "dashboard":
        window.DashboardView.render(this.currentProject, this.calculations, this.environmentalData);
        break;
      case "wizard":
        window.ProjectWizard.init(this.currentProject);
        break;
      case "scenariostudio":
        window.ScenarioStudioView.render(this.currentProject, this.calculations, this.environmentalData);
        break;
      case "technical":
        window.TechnicalAnalysisView.render(this.currentProject, this.calculations, this.environmentalData);
        break;
      case "recovery":
        window.NatureRecoveryView.render(this.currentProject, this.calculations, this.environmentalData);
        break;
      case "history":
        window.HistoryManager.render();
        break;
      case "methodology":
        window.MethodologyView.render();
        break;
      case "report":
        window.ReportView.render(this.currentProject, this.calculations, this.environmentalData);
        break;
    }
  },

  async onProjectSubmitted(formData) {
    await this.loadProjectAndCalculate(formData);
    this.switchView("dashboard");
  },

  async onMapLocationSelected(lat, lon) {
    if (this.currentProject) {
      this.currentProject.location.latitude = lat;
      this.currentProject.location.longitude = lon;
      const rev = await window.EnvironmentalDataService.reverseGeocode(lat, lon);
      this.currentProject.location.city = rev.city;
      this.currentProject.location.address = rev.display_name;

      await this.loadProjectAndCalculate(this.currentProject);
      this.renderCurrentView();
    }
  },

  showGlobalLoader(show, text = "Computing dynamic environmental indicators...") {
    const el = document.getElementById("global-loader");
    const txtEl = document.getElementById("global-loader-text");
    if (!el) return;
    if (txtEl) txtEl.innerText = text;
    if (show) el.classList.remove("hidden");
    else el.classList.add("hidden");
  }
};

document.addEventListener("DOMContentLoaded", () => {
  window.App.init();
});
