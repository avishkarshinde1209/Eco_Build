/**
 * EcoBuild Smart - Nature Recovery & Ecological Mitigation Component
 * Presents actionable two-phase mitigation plans:
 * Phase 1: Construction-Phase Mitigation (While Creating)
 * Phase 2: Post-Construction Operational Nature Recovery (After Construction)
 */

window.NatureRecoveryView = {
  render(project, calculations, environmentalData) {
    const container = document.getElementById("recovery-view");
    if (!container) return;

    const recovery = calculations?.recovery || window.NatureRecoveryCalculator.calculateRecoveryPlan(project, calculations, environmentalData);
    if (!recovery) {
      container.innerHTML = `<div class="p-8 text-center text-slate-500">Calculating nature recovery models...</div>`;
      return;
    }

    const p1 = recovery.phase1_construction;
    const p2 = recovery.phase2_operational;
    const bngNet = p2.biodiversity_net_gain.net_gain_pct;
    const paybackYears = p2.carbon_restoration_balance.carbon_neutrality_payback_years;

    container.innerHTML = `
      <div class="space-y-6 animate-fade-in">
        <!-- Top Banner / Summary Card -->
        <div class="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 rounded-2xl p-6 text-white shadow-lg border border-emerald-700/40 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div class="space-y-2">
            <div class="flex items-center gap-2">
              <span class="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 flex items-center gap-1.5">
                <span>🌱</span> Scientific Ecological Restoration Engine
              </span>
              <span class="text-xs text-slate-300">NBC 2016 Part 11 • CPCB 2016 • Akira Miyawaki Norms</span>
            </div>
            <h1 class="text-2xl sm:text-3xl font-black tracking-tight text-white">
              Ecosystem Recovery & Mitigation Portfolio
            </h1>
            <p class="text-xs sm:text-sm text-slate-300 max-w-3xl leading-relaxed">
              Active plan for <strong class="text-emerald-300">${project.name}</strong> (${project.location?.city || 'Kolhapur'}). 
              Quantified two-stage roadmap addressing environmental damage during physical construction and permanent restorative measures post-occupancy.
            </p>
          </div>

          <!-- Quick Net Gain Badges -->
          <div class="flex sm:flex-row lg:flex-col gap-3 shrink-0">
            <div class="bg-emerald-950/80 border border-emerald-600/40 rounded-xl p-3 text-center min-w-[140px]">
              <span class="text-[10px] uppercase font-bold text-emerald-400 block tracking-wider">Biodiversity Net Gain</span>
              <span class="text-2xl font-black text-emerald-200">+${bngNet}%</span>
              <span class="text-[10px] text-emerald-400 block">Above Baseline</span>
            </div>
            <div class="bg-slate-800/80 border border-slate-700 rounded-xl p-3 text-center min-w-[140px]">
              <span class="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">Carbon Payback</span>
              <span class="text-2xl font-black text-amber-300">~${paybackYears} yrs</span>
              <span class="text-[10px] text-slate-400 block">To Carbon Neutral</span>
            </div>
          </div>
        </div>

        <!-- TWO-PHASE MITIGATION TABS / CARDS -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

          <!-- ============================================== -->
          <!-- PHASE 1: DURING CONSTRUCTION (WHILE CREATING) -->
          <!-- ============================================== -->
          <div class="bg-white rounded-2xl border-2 border-amber-500/40 shadow-sm overflow-hidden flex flex-col">
            <!-- Header -->
            <div class="bg-gradient-to-r from-amber-600 to-amber-700 text-white p-5 flex items-center justify-between">
              <div class="flex items-center gap-2.5">
                <div class="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center text-lg font-black">
                  1
                </div>
                <div>
                  <span class="text-[10px] font-bold uppercase tracking-wider text-amber-200 block">Phase 1: During Construction</span>
                  <h2 class="text-base font-bold text-white">Impact Mitigation While Creating the Building</h2>
                </div>
              </div>
              <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-800/60 text-amber-100 border border-amber-400/40">
                Site Execution
              </span>
            </div>

            <!-- Content Body -->
            <div class="p-6 space-y-5 flex-1 text-xs">

              <!-- 1. Topsoil Salvage & Preservation -->
              <div class="bg-amber-50/70 border border-amber-200 rounded-xl p-4 space-y-2">
                <div class="flex items-start justify-between">
                  <div class="flex items-center gap-2">
                    <span class="text-base">🚜</span>
                    <h3 class="font-bold text-slate-800 text-sm">Topsoil Salvage & Biological Preservation</h3>
                  </div>
                  <span class="text-[10px] font-bold text-amber-800 bg-amber-200/60 px-2 py-0.5 rounded">
                    NBC 2016 Part 11
                  </span>
                </div>
                <p class="text-slate-600 leading-relaxed">
                  Before excavation, strip the top <strong>${p1.topsoil.excavation_depth_cm} cm</strong> of fertile humus layer from the building footprint. Stockpile at max <strong>${p1.topsoil.max_height_m} m</strong> height and sow nitrogen-fixing cover grass to preserve microbial mycorrhizae.
                </p>
                <div class="grid grid-cols-3 gap-2 pt-1 text-center">
                  <div class="bg-white p-2 rounded-lg border border-amber-200">
                    <span class="text-[9px] text-slate-400 font-bold block uppercase">Salvage Volume</span>
                    <span class="font-extrabold text-amber-900 text-sm">${p1.topsoil.salvage_volume_m3.toLocaleString()} m³</span>
                  </div>
                  <div class="bg-white p-2 rounded-lg border border-amber-200">
                    <span class="text-[9px] text-slate-400 font-bold block uppercase">Stockpile Footprint</span>
                    <span class="font-extrabold text-amber-900 text-sm">${p1.topsoil.stockpile_area_m2.toLocaleString()} m²</span>
                  </div>
                  <div class="bg-white p-2 rounded-lg border border-amber-200">
                    <span class="text-[9px] text-slate-400 font-bold block uppercase">Re-spread Area</span>
                    <span class="font-extrabold text-amber-900 text-sm">${p1.topsoil.reapplication_area_m2.toLocaleString()} m²</span>
                  </div>
                </div>
              </div>

              <!-- 2. CPCB Dust Barriers & Air Quality Protection -->
              <div class="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
                <div class="flex items-start justify-between">
                  <div class="flex items-center gap-2">
                    <span class="text-base">💨</span>
                    <h3 class="font-bold text-slate-800 text-sm">Air Quality & Fugitive Dust Suppression</h3>
                  </div>
                  <span class="text-[10px] font-bold text-slate-700 bg-slate-200 px-2 py-0.5 rounded">
                    CPCB Guidelines
                  </span>
                </div>
                <p class="text-slate-600 leading-relaxed">
                  Continuous perimeter wind-breaking GI sheet barrier with high-pressure atomized misting cannons to prevent airborne PM10 migration to neighboring settlements.
                </p>
                <div class="grid grid-cols-3 gap-2 pt-1 text-center">
                  <div class="bg-white p-2 rounded-lg border border-slate-200">
                    <span class="text-[9px] text-slate-400 font-bold block uppercase">Dust Barrier</span>
                    <span class="font-extrabold text-slate-800 text-sm">${p1.dust_control.barrier_length_m} m × 6m</span>
                  </div>
                  <div class="bg-white p-2 rounded-lg border border-slate-200">
                    <span class="text-[9px] text-slate-400 font-bold block uppercase">Mist Cannons</span>
                    <span class="font-extrabold text-slate-800 text-sm">${p1.dust_control.mist_cannons} Units</span>
                  </div>
                  <div class="bg-white p-2 rounded-lg border border-slate-200">
                    <span class="text-[9px] text-slate-400 font-bold block uppercase">Dust Abatement</span>
                    <span class="font-extrabold text-emerald-600 text-sm">~${p1.dust_control.pm10_capture_efficiency_pct}% PM10</span>
                  </div>
                </div>
              </div>

              <!-- 3. Low-Carbon Green Concrete & Rubble Circularity -->
              <div class="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
                <div class="flex items-start justify-between">
                  <div class="flex items-center gap-2">
                    <span class="text-base">🧱</span>
                    <h3 class="font-bold text-slate-800 text-sm">Green Concrete & Circular Rubble Utilization</h3>
                  </div>
                  <span class="text-[10px] font-bold text-slate-700 bg-slate-200 px-2 py-0.5 rounded">
                    IS 456 / CPCB 2016
                  </span>
                </div>
                <div class="grid grid-cols-2 gap-3 pt-1">
                  <div class="p-3 bg-white rounded-lg border border-slate-200 space-y-1">
                    <span class="text-[10px] font-bold text-emerald-800 block uppercase">35% GGBS / Fly Ash Blend</span>
                    <div class="text-lg font-black text-emerald-700">-${p1.green_concrete.co2_avoided_tonnes} t CO₂e</div>
                    <p class="text-[10px] text-slate-500">Upfront embodied cement emissions avoided</p>
                  </div>
                  <div class="p-3 bg-white rounded-lg border border-slate-200 space-y-1">
                    <span class="text-[10px] font-bold text-blue-800 block uppercase">Crushed Rubble Reuse</span>
                    <div class="text-lg font-black text-blue-700">${p1.rubble_circularity.reusable_subbase_m3} m³</div>
                    <p class="text-[10px] text-slate-500">Recycled aggregate for road & parking sub-base</p>
                  </div>
                </div>
              </div>

              <!-- 4. Erosion Control & Runoff Silt Traps -->
              <div class="flex items-center justify-between p-3 rounded-xl bg-slate-100/70 border border-slate-200 text-slate-600">
                <span class="font-semibold">Perimeter Silt Fencing & Sediment Traps:</span>
                <span class="font-bold text-slate-800">${p1.erosion_control.silt_fencing_m} m fencing • ${p1.erosion_control.sediment_traps} check traps</span>
              </div>
            </div>
          </div>

          <!-- ============================================== -->
          <!-- PHASE 2: AFTER CONSTRUCTION (OPERATIONAL RECOVERY) -->
          <!-- ============================================== -->
          <div class="bg-white rounded-2xl border-2 border-emerald-500/40 shadow-sm overflow-hidden flex flex-col">
            <!-- Header -->
            <div class="bg-gradient-to-r from-emerald-600 to-teal-700 text-white p-5 flex items-center justify-between">
              <div class="flex items-center gap-2.5">
                <div class="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center text-lg font-black">
                  2
                </div>
                <div>
                  <span class="text-[10px] font-bold uppercase tracking-wider text-emerald-200 block">Phase 2: Post-Construction</span>
                  <h2 class="text-base font-bold text-white">Permanent Ecological Nature Recovery</h2>
                </div>
              </div>
              <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-800/60 text-emerald-100 border border-emerald-400/40">
                Operational Lifecycle
              </span>
            </div>

            <!-- Content Body -->
            <div class="p-6 space-y-5 flex-1 text-xs">

              <!-- 1. Akira Miyawaki Dense Afforestation -->
              <div class="bg-emerald-50/70 border border-emerald-200 rounded-xl p-4 space-y-2">
                <div class="flex items-start justify-between">
                  <div class="flex items-center gap-2">
                    <span class="text-base">🌳</span>
                    <h3 class="font-bold text-slate-800 text-sm">Akira Miyawaki Ultra-Dense Native Micro-Forest</h3>
                  </div>
                  <span class="text-[10px] font-bold text-emerald-800 bg-emerald-200 px-2 py-0.5 rounded">
                    10x Faster Growth
                  </span>
                </div>
                <p class="text-slate-600 leading-relaxed">
                  Designate <strong>${p2.miyawaki_forest.designated_area_m2.toLocaleString()} m²</strong> of open site area for a 4-tier high-density native forest (${p2.miyawaki_forest.planting_density_m2} saplings/m²). Absorbs <strong>${p2.miyawaki_forest.carbon_sequestration_kg_yr.toLocaleString()} kg CO₂/yr</strong> with 30x higher biodiversity density.
                </p>
                <div class="grid grid-cols-3 gap-2 pt-1 text-center">
                  <div class="bg-white p-2 rounded-lg border border-emerald-200">
                    <span class="text-[9px] text-slate-400 font-bold block uppercase">Forest Footprint</span>
                    <span class="font-extrabold text-emerald-800 text-sm">${p2.miyawaki_forest.designated_area_m2.toLocaleString()} m²</span>
                  </div>
                  <div class="bg-white p-2 rounded-lg border border-emerald-200">
                    <span class="text-[9px] text-slate-400 font-bold block uppercase">Native Saplings</span>
                    <span class="font-extrabold text-emerald-800 text-sm">${p2.miyawaki_forest.total_saplings.toLocaleString()} Trees</span>
                  </div>
                  <div class="bg-white p-2 rounded-lg border border-emerald-200">
                    <span class="text-[9px] text-slate-400 font-bold block uppercase">Carbon Capture</span>
                    <span class="font-extrabold text-emerald-800 text-sm">~${p2.miyawaki_forest.carbon_sequestration_tonnes_yr} t/yr</span>
                  </div>
                </div>
              </div>

              <!-- 2. Sponge City Bioretention & Bioswales -->
              <div class="bg-blue-50/70 border border-blue-200 rounded-xl p-4 space-y-2">
                <div class="flex items-start justify-between">
                  <div class="flex items-center gap-2">
                    <span class="text-base">🌊</span>
                    <h3 class="font-bold text-slate-800 text-sm">Sponge City Vegetated Bioretention Swales</h3>
                  </div>
                  <span class="text-[10px] font-bold text-blue-800 bg-blue-200 px-2 py-0.5 rounded">
                    Aquifer Recharge
                  </span>
                </div>
                <p class="text-slate-600 leading-relaxed">
                  Engineered vegetated bioswales filter runoff from paved parking and internal access roads, removing 85% of suspended sediment and recharging the shallow water table.
                </p>
                <div class="grid grid-cols-3 gap-2 pt-1 text-center">
                  <div class="bg-white p-2 rounded-lg border border-blue-200">
                    <span class="text-[9px] text-slate-400 font-bold block uppercase">Bioswale Area</span>
                    <span class="font-extrabold text-blue-900 text-sm">${p2.sponge_city_bioswales.bioswale_footprint_m2} m²</span>
                  </div>
                  <div class="bg-white p-2 rounded-lg border border-blue-200">
                    <span class="text-[9px] text-slate-400 font-bold block uppercase">Storage Retention</span>
                    <span class="font-extrabold text-blue-900 text-sm">${p2.sponge_city_bioswales.storage_sump_m3} m³</span>
                  </div>
                  <div class="bg-white p-2 rounded-lg border border-blue-200">
                    <span class="text-[9px] text-slate-400 font-bold block uppercase">Infiltration Rate</span>
                    <span class="font-extrabold text-blue-900 text-sm">${p2.sponge_city_bioswales.daily_infiltration_litres.toLocaleString()} L/day</span>
                  </div>
                </div>
              </div>

              <!-- 3. Bio-Solar Synergy & On-Site Composting -->
              <div class="grid grid-cols-2 gap-3">
                <div class="bg-amber-50/60 border border-amber-200 rounded-xl p-3 space-y-1">
                  <div class="flex items-center gap-1.5 font-bold text-amber-900 text-xs">
                    <span>☀️🌱</span> Bio-Solar Synergy
                  </div>
                  <div class="text-base font-black text-amber-800">+${p2.bio_solar_roof.pv_efficiency_boost_pct}% Solar Yield</div>
                  <p class="text-[10px] text-slate-600">Green roof evapotranspiration cools solar PV modules by ~${p2.bio_solar_roof.temperature_reduction_c}°C (+${p2.bio_solar_roof.annual_bonus_kwh} kWh/yr bonus).</p>
                </div>

                <div class="bg-emerald-50/60 border border-emerald-200 rounded-xl p-3 space-y-1">
                  <div class="flex items-center gap-1.5 font-bold text-emerald-900 text-xs">
                    <span>♻️</span> Circular Bio-Composting
                  </div>
                  <div class="text-base font-black text-emerald-800">${p2.organic_composting.annual_bio_fertilizer_tonnes} t/yr Compost</div>
                  <p class="text-[10px] text-slate-600">100% of cafeteria organic waste composted on-site for Miyawaki forest enrichment.</p>
                </div>
              </div>

              <!-- 4. Biodiversity Net Gain Callout -->
              <div class="bg-gradient-to-r from-emerald-100 to-teal-50 border border-emerald-300 rounded-xl p-3 flex items-center justify-between text-slate-700">
                <div>
                  <span class="font-bold text-emerald-900 text-xs block">Biodiversity Net Gain Status</span>
                  <span class="text-[10px] text-emerald-700">${p2.biodiversity_net_gain.status}</span>
                </div>
                <span class="text-base font-black text-emerald-800">+${p2.biodiversity_net_gain.net_gain_pct}% Net Units</span>
              </div>
            </div>
          </div>
        </div>

        <!-- 4-TIER MIYAWAKI SPECIES SELECTION GUIDE -->
        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-4">
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
            <div>
              <h3 class="text-base font-bold text-slate-800">4-Tier Native Tropical Species Composition for Miyawaki Forest</h3>
              <p class="text-xs text-slate-500">Scientifically proven multilayer native species for ${project.location?.city || 'Regional'} agro-climatic conditions.</p>
            </div>
            <span class="text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
              Total Recommended Saplings: ${p2.miyawaki_forest.total_saplings.toLocaleString()}
            </span>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            ${p2.miyawaki_forest.species_tiers.map(tier => `
              <div class="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <div class="flex items-center justify-between">
                  <span class="text-[10px] font-bold uppercase text-slate-500 tracking-wider">${tier.tier}</span>
                  <span class="text-[10px] font-extrabold text-emerald-700 bg-emerald-100 px-1.5 py-0.2 rounded">${tier.pct}%</span>
                </div>
                <ul class="space-y-1.5 text-xs text-slate-700">
                  ${tier.species.map(s => `
                    <li class="flex items-center gap-1.5">
                      <span class="text-emerald-500 text-xs">🌿</span>
                      <span>${s}</span>
                    </li>
                  `).join('')}
                </ul>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- MITIGATION IMPLEMENTATION CHECKLIST & ACTIONS -->
        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div class="space-y-1">
            <h4 class="font-bold text-slate-800 text-sm">Download or Include in Official EIA Report</h4>
            <p class="text-xs text-slate-500">This comprehensive nature recovery roadmap is automatically incorporated into the downloadable Official EIA Report.</p>
          </div>
          <div class="flex items-center gap-3">
            <button onclick="window.App.switchView('report')" class="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow transition flex items-center gap-2">
              <span>📄 View in Full EIA Report</span>
            </button>
            <button onclick="window.print()" class="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 transition">
              <span>🖨️ Print Roadmap</span>
            </button>
          </div>
        </div>
      </div>
    `;
  }
};
