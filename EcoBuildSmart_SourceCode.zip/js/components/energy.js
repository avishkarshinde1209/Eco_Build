/**
 * EcoBuild Smart - Solar PV Potential & Carbon Displacement Module
 * Formulations based on MNRE & NREL PVWatts:
 * Capacity (kWp) = Area * 0.18 kWp/m²
 * Generation (kWh) = Capacity * Peak Sun Hours * 365 * 0.75 PR
 */

window.EnergyView = {
  render(project, calculations, environmentalData) {
    const container = document.getElementById("energy-view");
    if (!container) return;

    const sol = calculations.energy;
    const envSolar = environmentalData?.solar;

    container.innerHTML = `
      <div class="space-y-6">
        <!-- Header -->
        <div class="bg-white rounded-xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 border border-amber-300">
              ☀️ Solar Energy & Clean Power
            </span>
            <h1 class="text-2xl font-bold text-slate-800 tracking-tight mt-1">Rooftop Solar PV Feasibility</h1>
            <p class="text-xs text-slate-500 mt-0.5">
              Estimate installed solar capacity, annual clean kilowatt-hours generated, and carbon emissions displaced from the regional power grid.
            </p>
          </div>
          <button onclick="window.ExplainModal.open('solar_pv')" class="px-3.5 py-2 text-xs font-semibold rounded-lg bg-amber-50 text-amber-800 border border-amber-200 hover:bg-amber-100 flex items-center gap-1.5">
            <span>ℹ️</span> Inspect PVWatts Formula
          </button>
        </div>

        <!-- Metric KPI Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
            <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Installed Capacity</span>
            <div class="text-3xl font-bold text-amber-600 mt-1">${sol.installed_capacity_kwp} <span class="text-sm font-normal text-slate-500">kWp</span></div>
            <p class="text-xs text-slate-500 mt-1">Across ${sol.solar_allocated_area_m2} m² (${sol.solar_coverage_of_roof_pct}% of roof)</p>
          </div>

          <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
            <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Annual Clean Generation</span>
            <div class="text-3xl font-bold text-emerald-700 mt-1">${(sol.annual_generation_kwh / 1000).toFixed(1)} <span class="text-sm font-normal text-slate-500">MWh/yr</span></div>
            <p class="text-xs text-slate-500 mt-1">${sol.annual_generation_kwh.toLocaleString()} kWh generated</p>
          </div>

          <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
            <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Grid Electricity Offset</span>
            <div class="text-3xl font-bold text-teal-700 mt-1">${sol.demand_offset_percentage}%</div>
            <p class="text-xs text-slate-500 mt-1">Annual site load: ${sol.annual_demand_kwh.toLocaleString()} kWh</p>
          </div>

          <div class="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
            <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">CO₂ Emissions Avoided</span>
            <div class="text-3xl font-bold text-slate-800 mt-1">${sol.annual_co2_offset_tonnes} <span class="text-sm font-normal text-slate-500">t/yr</span></div>
            <p class="text-xs text-slate-500 mt-1">Displacing coal grid electricity (0.82 kg/kWh)</p>
          </div>
        </div>

        <!-- Technical Parameters & Engineering Specs -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div class="bg-white rounded-xl p-6 border border-slate-200 shadow-sm space-y-4">
            <h3 class="text-sm font-bold text-slate-800">Solar Technical Parameters & Deratings</h3>
            <div class="space-y-3 text-xs text-slate-600">
              <div class="flex justify-between border-b pb-2">
                <span>Location Peak Sun Hours (PSH):</span>
                <span class="font-bold text-slate-800">${sol.daily_peak_sun_hours} hrs/day (${envSolar?.solar_potential_category || 'Very Good'})</span>
              </div>
              <div class="flex justify-between border-b pb-2">
                <span>PV Module Technology:</span>
                <span class="font-bold text-slate-800">Monocrystalline Silicon PERC (${sol.panel_efficiency_pct}% eff.)</span>
              </div>
              <div class="flex justify-between border-b pb-2">
                <span>System Performance Ratio (PR):</span>
                <span class="font-bold text-slate-800">0.75 (75% net throughput after thermal/inverter losses)</span>
              </div>
              <div class="flex justify-between border-b pb-2">
                <span>Module Power Density:</span>
                <span class="font-bold text-slate-800">180 Wp / m²</span>
              </div>
              <div class="flex justify-between border-b pb-2">
                <span>Rooftop Solar Orientation:</span>
                <span class="font-bold text-slate-800">${project.energy?.roof_orientation || 'South / South-West'}</span>
              </div>
              <div class="flex justify-between pt-1">
                <span>Grid Emission Factor:</span>
                <span class="font-bold text-slate-800">0.82 kg CO₂e / kWh (CEA Baseline v19)</span>
              </div>
            </div>
          </div>

          <div class="bg-amber-50/50 rounded-xl p-6 border border-amber-200 shadow-sm space-y-4">
            <h3 class="text-sm font-bold text-amber-900">Co-Location with Green Roof (Bio-Solar Synergy)</h3>
            <p class="text-xs text-amber-800 leading-relaxed">
              Standard photovoltaic panels suffer significant power output degradation at high surface temperatures (typically -0.4% efficiency loss per °C rise above 25°C).
            </p>
            <div class="bg-white/80 p-4 rounded-xl border border-amber-200/60 text-xs space-y-2">
              <div class="font-bold text-amber-950">Scientific Bio-Solar Effect:</div>
              <p class="text-amber-900">
                Co-locating solar PV panels over an extensive green roof allows natural plant transpiration to cool ambient air beneath the modules by <strong>3°C to 6°C</strong>, boosting electrical power generation efficiency by an estimated <strong>3.5% to 5.0%</strong> compared to bare concrete rooftops.
              </p>
            </div>
            <div class="text-[11px] text-amber-700/80">
              * Recommended configuration: Mount PV racking 60-80cm elevated above Sedum vegetation layer.
            </div>
          </div>
        </div>
      </div>
    `;
  }
};
