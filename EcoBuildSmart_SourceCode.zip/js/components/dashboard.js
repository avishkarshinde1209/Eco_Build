/**
 * EcoBuild Smart - Dynamic Environmental Dashboard
 * Renders environmental deficits, site geometry, real-world climate indicators,
 * recovery plan targets, and interactive explainability triggers.
 */

window.DashboardView = {
  charts: {},

  render(project, calculations, environmentalData) {
    const container = document.getElementById("dashboard-view");
    if (!container) return;

    const def = calculations;
    const gc = def.green_cover;
    const tree = def.tree_impact;
    const runoff = def.runoff;
    const water = def.water_demand;
    const rwh = def.rwh;
    const energy = def.energy;
    const carbon = def.carbon;
    const uhi = def.uhi;
    const score = def.score;
    const env = environmentalData;

    container.innerHTML = `
      <!-- Top Project Header Banner -->
      <div class="bg-white rounded-xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2 mb-1">
            <span class="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-300">
              ${project.building_type}
            </span>
            <span class="text-xs text-slate-500">
              📍 ${project.location.address || project.location.city} (${project.location.latitude.toFixed(4)}, ${project.location.longitude.toFixed(4)})
            </span>
          </div>
          <h1 class="text-2xl font-bold text-slate-800 tracking-tight">${project.name}</h1>
          <p class="text-xs text-slate-500 mt-0.5">
            Plot Area: <strong>${project.site.plot_area.toLocaleString()} m²</strong> • Built Footprint: <strong>${project.site.built_up_area.toLocaleString()} m²</strong> (${project.site.floors} floors) • Occupancy: <strong>${project.water.occupants} persons</strong>
          </p>
        </div>

        <!-- Composite Score Card -->
        <div class="flex items-center gap-4 bg-slate-50 border border-slate-200 rounded-xl p-4 self-start md:self-auto">
          <div class="text-right">
            <div class="text-xs font-semibold text-slate-500 uppercase tracking-wider">Environmental Score</div>
            <div class="text-xs font-bold text-emerald-800">${score.tier}</div>
          </div>
          <div class="relative w-16 h-16 flex items-center justify-center rounded-full border-4 ${score.composite_score >= 70 ? 'border-emerald-500 text-emerald-600' : 'border-amber-500 text-amber-600'} bg-white font-extrabold text-2xl shadow-sm">
            ${score.composite_score}
          </div>
        </div>
      </div>

      <!-- Quick Action / Tab Bar -->
      <div class="flex flex-wrap items-center justify-between gap-3 pt-2">
        <div class="flex flex-wrap items-center gap-2 text-xs">
          <span class="text-slate-500 font-semibold">Jump to analyses:</span>
          <button onclick="window.App.switchView('recovery')" class="px-3 py-1.5 rounded-lg bg-emerald-600 text-white font-bold hover:bg-emerald-700 shadow-sm transition flex items-center gap-1.5">
            <span>🌱</span> Nature Recovery
          </button>
          <button onclick="window.HistoryManager.saveNamedSnapshot()" class="px-3 py-1.5 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-300 font-bold hover:bg-emerald-100 transition flex items-center gap-1.5">
            <span>💾</span> Save Snapshot
          </button>
          <button onclick="window.App.switchView('scenariostudio')" class="px-3 py-1.5 rounded-lg bg-teal-50 text-teal-800 border border-teal-200 font-semibold hover:bg-teal-100 transition">
            ⚖️ Scenario Studio
          </button>
          <button onclick="window.App.switchView('technical')" class="px-3 py-1.5 rounded-lg bg-slate-100 text-slate-800 border border-slate-300 font-semibold hover:bg-slate-200 transition">
            🔬 Technical Studio
          </button>
          <button onclick="window.App.switchView('history')" class="px-3 py-1.5 rounded-lg bg-blue-50 text-blue-800 border border-blue-200 font-semibold hover:bg-blue-100 transition">
            📁 Plan History
          </button>
          <button onclick="window.App.switchView('report')" class="px-3 py-1.5 rounded-lg bg-slate-100 text-slate-800 border border-slate-300 font-semibold hover:bg-slate-200 transition">
            📄 Academic Report
          </button>
        </div>

        <div class="text-xs text-slate-400">
          Last calculated: ${new Date(def.timestamp).toLocaleTimeString()}
        </div>
      </div>

      <!-- SECTION 1: ENVIRONMENTAL DEFICIT (MAIN REQUIREMENT) -->
      <div class="space-y-3">
        <div class="flex items-center justify-between">
          <h2 class="text-lg font-bold text-slate-800 flex items-center gap-2">
            <span>⚠️</span> Environmental Deficit & Impact Indicators
          </h2>
          <span class="text-xs text-slate-500">Dynamically computed from site alterations & climate inputs</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
          <!-- 1. Carbon Impact -->
          <div class="bg-white rounded-xl p-5 border border-slate-200 shadow-sm relative group hover:border-slate-300 transition">
            <div class="flex justify-between items-start">
              <div>
                <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Carbon Deficit</span>
                <div class="text-2xl font-bold text-slate-800 mt-1">${carbon.embodied_emissions.total_embodied_tonnes} t CO₂e</div>
              </div>
              <button onclick="window.ExplainModal.open('carbon_deficit')" class="p-1.5 text-xs text-emerald-600 hover:text-emerald-800 bg-emerald-50 rounded-lg hover:bg-emerald-100 transition" title="Inspect Formula & Sources">
                ℹ️ Explain
              </button>
            </div>
            <div class="mt-3 text-xs text-slate-600 space-y-1">
              <div>• Embodied structural carbon: <strong>${Math.round(carbon.embodied_emissions.building_materials_kg / 1000)} t</strong></div>
              <div>• Active tree sequestration lost: <strong>${carbon.vegetation_carbon.annual_sequestration_lost_kg} kg/yr</strong></div>
              <div>• Biomass carbon released: <strong>${carbon.vegetation_carbon.biomass_carbon_loss_kg} kg</strong></div>
            </div>
            <div class="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
              <span>Source: IGBC / IPCC Baseline</span>
              <span class="text-orange-600 font-medium">🟠 Estimated</span>
            </div>
          </div>

          <!-- 2. Stormwater Runoff Deficit -->
          <div class="bg-white rounded-xl p-5 border border-slate-200 shadow-sm relative group hover:border-slate-300 transition">
            <div class="flex justify-between items-start">
              <div>
                <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Stormwater Runoff Increase</span>
                <div class="text-2xl font-bold text-blue-700 mt-1">+${runoff.impact_summary.peak_runoff_increase_pct}% Peak</div>
              </div>
              <button onclick="window.ExplainModal.open('runoff_deficit')" class="p-1.5 text-xs text-blue-600 hover:text-blue-800 bg-blue-50 rounded-lg hover:bg-blue-100 transition" title="Inspect Formula & Sources">
                ℹ️ Explain
              </button>
            </div>
            <div class="mt-3 text-xs text-slate-600 space-y-1">
              <div>• Peak runoff rate (Q): <strong>${runoff.proposed_development.peak_runoff_m3_hr} m³/hr</strong> (vs pre: ${runoff.pre_development.peak_runoff_m3_hr})</div>
              <div>• Additional annual runoff: <strong>${(runoff.impact_summary.annual_additional_runoff_litres / 1000).toLocaleString()} m³</strong></div>
              <div>• Groundwater infiltration lost: <strong>~${runoff.impact_summary.infiltration_lost_pct}%</strong></div>
            </div>
            <div class="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
              <span>Model: Rational Q = C × I × A</span>
              <span class="text-emerald-700 font-medium">🟢 High Confidence</span>
            </div>
          </div>

          <!-- 3. Tree Loss & Canopy Deficit -->
          <div class="bg-white rounded-xl p-5 border border-slate-200 shadow-sm relative group hover:border-slate-300 transition">
            <div class="flex justify-between items-start">
              <div>
                <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Tree & Canopy Loss</span>
                <div class="text-2xl font-bold text-rose-700 mt-1">-${tree.trees_removed} Trees</div>
              </div>
              <button onclick="window.ExplainModal.open('tree_replacement')" class="p-1.5 text-xs text-rose-600 hover:text-rose-800 bg-rose-50 rounded-lg hover:bg-rose-100 transition" title="Inspect Formula & Sources">
                ℹ️ Explain
              </button>
            </div>
            <div class="mt-3 text-xs text-slate-600 space-y-1">
              <div>• Tree felling ratio: <strong>${tree.tree_loss_pct}% of site trees</strong></div>
              <div>• Canopy shade footprint lost: <strong>${tree.estimated_canopy_lost_m2} m²</strong></div>
              <div>• Compensatory planting requirement: <strong>${tree.recommended_planting_quantity} trees (${tree.replacement_ratio}:1)</strong></div>
            </div>
            <div class="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
              <span>Standard: Maharashtra Tree Act</span>
              <span class="text-emerald-700 font-medium">🟢 High Confidence</span>
            </div>
          </div>

          <!-- 4. Green Cover & Impervious Fraction -->
          <div class="bg-white rounded-xl p-5 border border-slate-200 shadow-sm relative group hover:border-slate-300 transition">
            <div class="flex justify-between items-start">
              <div>
                <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Impervious Hardscape</span>
                <div class="text-2xl font-bold text-amber-700 mt-1">${gc.impervious_pct}% of Site</div>
              </div>
              <button onclick="window.ExplainModal.open('uhi_index')" class="p-1.5 text-xs text-amber-600 hover:text-amber-800 bg-amber-50 rounded-lg hover:bg-amber-100 transition" title="Inspect Formula & Sources">
                ℹ️ Explain
              </button>
            </div>
            <div class="mt-3 text-xs text-slate-600 space-y-1">
              <div>• Hard impervious surface: <strong>${gc.impervious_area_m2.toLocaleString()} m²</strong></div>
              <div>• Remaining natural green: <strong>${gc.existing_green_pct}%</strong> (Target: 25%)</div>
              <div>• Green cover deficit: <strong>${gc.green_deficit_m2.toLocaleString()} m²</strong></div>
            </div>
            <div class="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
              <span>Area Cadastre Calculation</span>
              <span class="text-blue-700 font-medium">🔵 User Supplied</span>
            </div>
          </div>

          <!-- 5. Urban Heat Island (UHI) Index -->
          <div class="bg-white rounded-xl p-5 border border-slate-200 shadow-sm relative group hover:border-slate-300 transition">
            <div class="flex justify-between items-start">
              <div>
                <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Heat Island Vulnerability</span>
                <div class="text-2xl font-bold text-${uhi.uhi_color}-600 mt-1">${uhi.uhi_vulnerability_index} / 100</div>
              </div>
              <button onclick="window.ExplainModal.open('uhi_index')" class="p-1.5 text-xs text-purple-600 hover:text-purple-800 bg-purple-50 rounded-lg hover:bg-purple-100 transition" title="Inspect Formula & Sources">
                ℹ️ Explain
              </button>
            </div>
            <div class="mt-3 text-xs text-slate-600 space-y-1">
              <div>• Thermal risk level: <strong>${uhi.uhi_risk_level}</strong></div>
              <div>• Average site solar albedo: <strong>${uhi.average_site_albedo}</strong> (Concrete/Asphalt)</div>
              <div>• Active evapotranspiration area: <strong>${uhi.evapotranspirative_cooling_area_m2.toLocaleString()} m²</strong></div>
            </div>
            <div class="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
              <span>Model: EPA Thermal Albedo Matrix</span>
              <span class="text-orange-600 font-medium">🟠 Estimated</span>
            </div>
          </div>

          <!-- 6. Water Deficit & Consumption -->
          <div class="bg-white rounded-xl p-5 border border-slate-200 shadow-sm relative group hover:border-slate-300 transition">
            <div class="flex justify-between items-start">
              <div>
                <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Annual Water Demand</span>
                <div class="text-2xl font-bold text-teal-700 mt-1">${water.annual_demand_m3.toLocaleString()} m³/yr</div>
              </div>
              <button onclick="window.ExplainModal.open('rwh_potential')" class="p-1.5 text-xs text-teal-600 hover:text-teal-800 bg-teal-50 rounded-lg hover:bg-teal-100 transition" title="Inspect Formula & Sources">
                ℹ️ Explain
              </button>
            </div>
            <div class="mt-3 text-xs text-slate-600 space-y-1">
              <div>• Daily consumption: <strong>${water.daily_demand_litres.toLocaleString()} L/day</strong> (${water.lpcd} LPCD)</div>
              <div>• Non-potable flush & landscape: <strong>${water.daily_non_potable_litres.toLocaleString()} L/day</strong></div>
              <div>• Rainwater harvesting potential: <strong>${(rwh.annual_potential_litres / 1000).toLocaleString()} m³/yr</strong> (${rwh.demand_offset_percentage}% offset)</div>
            </div>
            <div class="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
              <span>NBC 2016 Standards</span>
              <span class="text-emerald-700 font-medium">🟢 High Confidence</span>
            </div>
          </div>
        </div>
      </div>

      <!-- SECTION 2: CHARTS & RADAR SCORE -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 pt-2">
        <!-- Chart 1: Surface Area Breakdown (Doughnut) -->
        <div class="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
          <div class="flex items-center justify-between">
            <h3 class="text-sm font-bold text-slate-800">Site Land-Cover Breakdown</h3>
            <span class="text-xs text-slate-500">${project.site.plot_area} m² Total</span>
          </div>
          <div class="relative h-60 flex items-center justify-center">
            <canvas id="chart-surface-doughnut"></canvas>
          </div>
          <div class="grid grid-cols-2 gap-2 text-xs border-t pt-3">
            <div><span class="inline-block w-2.5 h-2.5 rounded-full bg-slate-700 mr-1.5"></span>Built Footprint: <strong>${project.site.built_up_area} m²</strong></div>
            <div><span class="inline-block w-2.5 h-2.5 rounded-full bg-slate-400 mr-1.5"></span>Concrete Paved: <strong>${project.surfaces.concrete_area} m²</strong></div>
            <div><span class="inline-block w-2.5 h-2.5 rounded-full bg-emerald-600 mr-1.5"></span>Green Cover: <strong>${project.vegetation.existing_green_area} m²</strong></div>
            <div><span class="inline-block w-2.5 h-2.5 rounded-full bg-amber-600 mr-1.5"></span>Open Ground: <strong>${project.surfaces.soil_open_ground || 0} m²</strong></div>
          </div>
        </div>

        <!-- Chart 2: Monthly Rainwater Harvesting Potential (Bar Chart) -->
        <div class="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
          <div class="flex items-center justify-between">
            <h3 class="text-sm font-bold text-slate-800">Monthly RWH Harvest (m³)</h3>
            <span class="text-xs text-blue-700 font-semibold">${(rwh.annual_potential_litres / 1000).toFixed(0)} m³ Annual</span>
          </div>
          <div class="relative h-60">
            <canvas id="chart-monthly-rwh"></canvas>
          </div>
          <p class="text-[11px] text-slate-500 border-t pt-2">
            Based on roof area (${project.site.roof_area} m²), runoff coeff 0.85, and filter efficiency 0.85 against local monthly precipitation.
          </p>
        </div>

        <!-- Chart 3: Sustainability Multi-Criteria Radar -->
        <div class="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-4">
          <div class="flex items-center justify-between">
            <h3 class="text-sm font-bold text-slate-800">7-Dimension Radar Score</h3>
            <span class="text-xs font-bold text-emerald-700">${score.composite_score}/100</span>
          </div>
          <div class="relative h-60 flex items-center justify-center">
            <canvas id="chart-score-radar"></canvas>
          </div>
          <div class="text-[11px] text-slate-500 border-t pt-2 flex items-center justify-between">
            <span>Scientific Indicators</span>
            <button onclick="window.App.switchView('methodology')" class="text-emerald-700 font-semibold hover:underline">
              Inspect Formulas &rarr;
            </button>
          </div>
        </div>
      </div>

      <!-- SECTION 3: REAL ENVIRONMENTAL CONDITIONS -->
      <div class="space-y-3 pt-2">
        <div class="flex items-center justify-between">
          <h2 class="text-lg font-bold text-slate-800 flex items-center gap-2">
            <span>🌐</span> Real Online Environmental Data
          </h2>
          <span class="text-xs text-slate-500">Live feeds from Open-Meteo, CAMS, and NASA POWER</span>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
          <!-- Temp -->
          <div class="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm">
            <div class="text-[10px] text-slate-400 font-bold uppercase">Temperature</div>
            <div class="text-xl font-bold text-slate-800 mt-0.5">${env.weather.temperature.current_c}°C</div>
            <div class="text-[11px] text-slate-500">Max: ${env.weather.temperature.max_c}° | Min: ${env.weather.temperature.min_c}°</div>
            <div class="text-[9px] text-emerald-700 font-medium mt-1 truncate">🟢 ${env.weather.source}</div>
          </div>

          <!-- Rainfall -->
          <div class="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm">
            <div class="text-[10px] text-slate-400 font-bold uppercase">Annual Rainfall</div>
            <div class="text-xl font-bold text-blue-700 mt-0.5">${env.rainfall.annual_rainfall_mm} mm</div>
            <div class="text-[11px] text-slate-500">Intensity: ${env.rainfall.peak_intensity_mm_hr} mm/hr</div>
            <div class="text-[9px] text-emerald-700 font-medium mt-1 truncate">🟢 ERA5-Land Reanalysis</div>
          </div>

          <!-- AQI -->
          <div class="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm">
            <div class="text-[10px] text-slate-400 font-bold uppercase">Air Quality (AQI)</div>
            <div class="text-xl font-bold text-${env.airQuality.category_color}-600 mt-0.5">${env.airQuality.aqi}</div>
            <div class="text-[11px] text-slate-500">${env.airQuality.category}</div>
            <div class="text-[9px] text-emerald-700 font-medium mt-1 truncate">🟢 Copernicus CAMS</div>
          </div>

          <!-- PM2.5 -->
          <div class="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm">
            <div class="text-[10px] text-slate-400 font-bold uppercase">PM2.5 / PM10</div>
            <div class="text-xl font-bold text-slate-800 mt-0.5">${env.airQuality.pm25} <span class="text-xs font-normal text-slate-400">µg/m³</span></div>
            <div class="text-[11px] text-slate-500">PM10: ${env.airQuality.pm10} µg/m³</div>
            <div class="text-[9px] text-emerald-700 font-medium mt-1 truncate">🟢 WHO Benchmark: 15</div>
          </div>

          <!-- Solar -->
          <div class="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm">
            <div class="text-[10px] text-slate-400 font-bold uppercase">Solar Sunshine</div>
            <div class="text-xl font-bold text-amber-600 mt-0.5">${env.solar.daily_peak_sun_hours} <span class="text-xs font-normal text-slate-400">hrs/d</span></div>
            <div class="text-[11px] text-slate-500">${env.solar.annual_solar_radiation_kwh_m2} kWh/m²/yr</div>
            <div class="text-[9px] text-emerald-700 font-medium mt-1 truncate">🟢 NASA POWER</div>
          </div>

          <!-- Humidity & Wind -->
          <div class="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm">
            <div class="text-[10px] text-slate-400 font-bold uppercase">Humidity & Wind</div>
            <div class="text-xl font-bold text-slate-800 mt-0.5">${env.weather.humidity_pct}%</div>
            <div class="text-[11px] text-slate-500">Wind: ${env.weather.wind_speed_kmh} km/h</div>
            <div class="text-[9px] text-emerald-700 font-medium mt-1 truncate">🟢 Surface Station</div>
          </div>
        </div>
      </div>

      <!-- SECTION 4: RECOVERY REQUIREMENTS & GREEN INFRASTRUCTURE PLAN -->
      <div class="bg-gradient-to-br from-emerald-900 via-teal-900 to-slate-900 text-white rounded-xl p-6 shadow-md space-y-5">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-700/60 text-emerald-200 border border-emerald-500/30">
              ⚡ Actionable Engineering Targets
            </span>
            <h2 class="text-xl md:text-2xl font-bold tracking-tight mt-1">Your Environmental Recovery Plan</h2>
            <p class="text-xs text-emerald-200/90 mt-0.5">
              Specific interventions dynamically sized to neutralize stormwater, tree felling, and carbon deficits.
            </p>
          </div>

          <button onclick="window.App.switchView('scenariostudio')" class="px-4 py-2 rounded-lg text-xs font-bold bg-amber-400 hover:bg-amber-300 text-slate-900 shadow transition flex items-center gap-2 self-start md:self-auto">
            <span>Test in Scenario Studio</span>
            <span>&rarr;</span>
          </button>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
          <!-- Tree Planting -->
          <div class="bg-white/10 backdrop-blur-sm border border-white/10 rounded-xl p-4 space-y-2">
            <div class="text-2xl font-black text-amber-300">${tree.recommended_planting_quantity} Trees</div>
            <div class="text-xs font-bold text-white">Compensatory Native Planting</div>
            <p class="text-[11px] text-emerald-100/80 leading-relaxed">
              Plant ${tree.recommended_planting_quantity} trees (${tree.replacement_ratio}:1 ratio) to replace ${tree.trees_removed} removed trees and recover ${tree.projected_canopy_10yr_m2.toLocaleString()} m² canopy.
            </p>
          </div>

          <!-- Permeable Pavement -->
          <div class="bg-white/10 backdrop-blur-sm border border-white/10 rounded-xl p-4 space-y-2">
            <div class="text-2xl font-black text-emerald-300">${calculations.green_infra_potential.recommended_permeable_pavement_m2.toLocaleString()} m²</div>
            <div class="text-xs font-bold text-white">Permeable Pavement Conversion</div>
            <p class="text-[11px] text-emerald-100/80 leading-relaxed">
              Convert ${calculations.green_infra_potential.permeable_pavement_conversion_pct}% of concrete pavement to porous pavers to restore infiltration and cut peak runoff.
            </p>
          </div>

          <!-- Green Roof -->
          <div class="bg-white/10 backdrop-blur-sm border border-white/10 rounded-xl p-4 space-y-2">
            <div class="text-2xl font-black text-teal-300">${calculations.green_infra_potential.recommended_green_roof_m2.toLocaleString()} m²</div>
            <div class="text-xs font-bold text-white">Extensive Sedum Green Roof</div>
            <p class="text-[11px] text-emerald-100/80 leading-relaxed">
              Retrofit ~35% of flat terrace roof with lightweight vegetative matting (65% rainwater retention and thermal cooling).
            </p>
          </div>

          <!-- Rainwater Storage -->
          <div class="bg-white/10 backdrop-blur-sm border border-white/10 rounded-xl p-4 space-y-2">
            <div class="text-2xl font-black text-blue-300">${(rwh.recommended_storage_range_litres.optimum / 1000).toLocaleString()} kL</div>
            <div class="text-xs font-bold text-white">RWH Storage Tank Sizing</div>
            <p class="text-[11px] text-emerald-100/80 leading-relaxed">
              Install a ${rwh.recommended_storage_range_litres.optimum.toLocaleString()} L capacity tank to offset ${rwh.demand_offset_percentage}% of annual campus water needs.
            </p>
          </div>

          <!-- Rooftop Solar PV -->
          <div class="bg-white/10 backdrop-blur-sm border border-white/10 rounded-xl p-4 space-y-2">
            <div class="text-2xl font-black text-yellow-300">${energy.installed_capacity_kwp} kWp</div>
            <div class="text-xs font-bold text-white">Rooftop Solar PV Array</div>
            <p class="text-[11px] text-emerald-100/80 leading-relaxed">
              Deploy ~${energy.solar_allocated_area_m2} m² of solar panels generating ${energy.annual_generation_kwh.toLocaleString()} kWh/year and avoiding ${energy.annual_co2_offset_tonnes} t CO₂e.
            </p>
          </div>
        </div>
      </div>

      <!-- SECTION 4: NATURE RECOVERY & CIRCULAR MATERIALS SHOWCASE -->
      <div class="bg-gradient-to-r from-emerald-950 via-teal-950 to-slate-900 rounded-2xl p-6 text-white border border-emerald-700/50 shadow-md flex flex-col md:flex-row items-center justify-between gap-6">
        <div class="space-y-2">
          <div class="flex items-center gap-2">
            <span class="text-xs font-bold text-emerald-400 bg-emerald-900/60 px-2.5 py-0.5 rounded-full border border-emerald-600/40">
              🌱 Actionable Restoration Engine
            </span>
            <span class="text-xs text-slate-300">Phase 1 (Creation) + Phase 2 (Operational Nature Recovery)</span>
          </div>
          <h3 class="text-xl font-bold text-white">Ecological Restoration, Miyawaki Afforestation & Waste Circularity</h3>
          <p class="text-xs text-slate-300 max-w-2xl leading-relaxed">
            Quantified action plan: Topsoil salvage (${Math.round((project.site.built_up_area || 2200) * 0.20)} m³ preserved under NBC 2016), C&D waste diversion (${project.waste?.construction_waste_tonnes || 330} tonnes @ ${project.waste?.recycling_pct || 65}% circular reuse), and Akira Miyawaki ultra-dense native micro-forest (+${calculations.recovery?.phase2_operational?.biodiversity_net_gain?.net_gain_pct || 42}% Biodiversity Net Gain).
          </p>
        </div>
        <button onclick="window.App.switchView('recovery')" class="px-5 py-2.5 rounded-xl text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-lg shadow-emerald-500/20 transition flex items-center gap-2 shrink-0">
          <span>Explore Nature Recovery Roadmap →</span>
        </button>
      </div>
    `;

    // Render Charts
    setTimeout(() => {
      this.initCharts(project, calculations);
    }, 100);
  },

  initCharts(project, calculations) {
    if (!window.Chart) return;

    // Destroy existing instances if any
    Object.values(this.charts).forEach(c => { if (c) c.destroy(); });
    this.charts = {};

    // 1. Surface Doughnut
    const ctxSurf = document.getElementById("chart-surface-doughnut");
    if (ctxSurf) {
      this.charts.surface = new window.Chart(ctxSurf, {
        type: "doughnut",
        data: {
          labels: ["Building Footprint", "Concrete Paved", "Existing Green", "Open Ground / Tiles"],
          datasets: [{
            data: [
              project.site.built_up_area,
              project.surfaces.concrete_area,
              project.vegetation.existing_green_area,
              Math.max(0, project.site.plot_area - project.site.built_up_area - project.surfaces.concrete_area - project.vegetation.existing_green_area)
            ],
            backgroundColor: ["#334155", "#94a3b8", "#059669", "#d97706"],
            borderWidth: 2,
            borderColor: "#ffffff"
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          cutout: "68%"
        }
      });
    }

    // 2. Monthly RWH Bar Chart
    const ctxRwh = document.getElementById("chart-monthly-rwh");
    if (ctxRwh) {
      const monthly = calculations.rwh.monthly_harvest || [];
      this.charts.rwh = new window.Chart(ctxRwh, {
        type: "bar",
        data: {
          labels: monthly.map(m => m.month),
          datasets: [{
            label: "Harvestable Volume (m³)",
            data: monthly.map(m => m.harvest_m3),
            backgroundColor: "#2563eb",
            borderRadius: 4
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: {
            y: { beginAtZero: true, grid: { color: "#f1f5f9" } },
            x: { grid: { display: false } }
          }
        }
      });
    }

    // 3. Radar Chart
    const ctxRadar = document.getElementById("chart-score-radar");
    if (ctxRadar) {
      const sub = calculations.score.sub_indicators;
      this.charts.radar = new window.Chart(ctxRadar, {
        type: "radar",
        data: {
          labels: [
            "Green Cover",
            "Tree Retention",
            "Stormwater",
            "Water Consv",
            "Clean Energy",
            "Permeability",
            "Waste Mgmt"
          ],
          datasets: [{
            label: "Site Performance Score",
            data: [
              sub.green_cover.score,
              sub.tree_retention.score,
              sub.stormwater_mgmt.score,
              sub.water_conservation.score,
              sub.renewable_energy.score,
              sub.surface_permeability.score,
              sub.waste_management.score
            ],
            backgroundColor: "rgba(16, 185, 129, 0.25)",
            borderColor: "#059669",
            pointBackgroundColor: "#047857",
            pointBorderColor: "#ffffff",
            pointHoverBackgroundColor: "#ffffff",
            pointHoverBorderColor: "#047857",
            borderWidth: 2
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: {
            r: {
              beginAtZero: true,
              max: 100,
              ticks: { stepSize: 20, display: false },
              grid: { color: "#e2e8f0" }
            }
          }
        }
      });
    }
  }
};
