/**
 * EcoBuild Smart - Consolidated Scenario & Simulation Studio
 * Seamlessly integrates the 3-State Before vs After Comparative Model
 * with the Real-Time Reactive What-If Sensitivity Sliders.
 */

window.ScenarioStudioView = {
  interventions: {
    trees_planted: 90,
    green_roof_m2: 600,
    permeable_pavement_m2: 1200,
    rwh_tank_capacity_l: 85000,
    solar_pv_area_m2: 700
  },
  charts: {},

  render(project, calculations, environmentalData) {
    const container = document.getElementById("scenario-studio-view");
    if (!container) return;

    if (project.interventions) {
      this.interventions = { ...project.interventions };
    }

    const plot = project.site.plot_area;
    const roof = project.site.roof_area;
    const concrete = project.surfaces.concrete_area;

    container.innerHTML = `
      <div class="space-y-6">
        <!-- Studio Header -->
        <div class="bg-white rounded-xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-300">
              ⚖️ Tri-State Comparative & Sensitivity Studio
            </span>
            <h1 class="text-2xl font-bold text-slate-800 tracking-tight mt-1">Scenario & What-If Studio</h1>
            <p class="text-xs text-slate-500 mt-0.5">
              Simulate policy interventions using live sensitivity sliders. The tri-state comparative model updates immediately.
            </p>
          </div>

          <div class="flex items-center gap-2">
            <button onclick="window.ScenarioStudioView.resetToRecommended()" class="px-3 py-1.5 text-xs font-bold rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-300 hover:bg-emerald-100 transition">
              Reset Recommendations
            </button>
            <button onclick="window.ScenarioStudioView.applyToPlan()" class="px-4 py-1.5 text-xs font-bold rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 shadow-sm transition">
              Apply to Plan ✓
            </button>
          </div>
        </div>

        <!-- Dual Pane Studio: Left Sliders (5 cols), Right Live Tri-State Comparison (7 cols) -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <!-- Left: Sensitivity Sliders Pane (5 cols) -->
          <div class="lg:col-span-5 bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-5">
            <div class="flex items-center justify-between border-b pb-3">
              <h3 class="text-sm font-bold text-slate-800 flex items-center gap-2">
                <span>🎛️</span> Green Infrastructure Levers
              </h3>
              <span class="text-[10px] text-slate-400 font-semibold uppercase">Live Reactivity</span>
            </div>

            <!-- Slider 1: Compensatory Trees -->
            <div class="space-y-1.5">
              <div class="flex justify-between items-center text-xs">
                <label class="font-bold text-slate-700">🌳 Native Trees Planted</label>
                <span id="studio-val-trees" class="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  ${this.interventions.trees_planted} Trees
                </span>
              </div>
              <input 
                type="range" 
                min="0" 
                max="500" 
                step="5" 
                value="${this.interventions.trees_planted}" 
                oninput="window.ScenarioStudioView.onSliderChange('trees_planted', parseInt(this.value))"
                class="w-full accent-emerald-600 cursor-pointer">
              <div class="flex justify-between text-[10px] text-slate-400">
                <span>0 Trees</span>
                <span>Recommended: ${calculations.tree_impact.recommended_planting_quantity}</span>
                <span>500</span>
              </div>
            </div>

            <!-- Slider 2: Green Roof Area -->
            <div class="space-y-1.5">
              <div class="flex justify-between items-center text-xs">
                <label class="font-bold text-slate-700">🌿 Extensive Green Roof (m²)</label>
                <span id="studio-val-roof" class="font-bold text-teal-700 bg-teal-50 px-2 py-0.5 rounded border border-teal-200">
                  ${this.interventions.green_roof_m2} m² (${Math.round((this.interventions.green_roof_m2 / roof) * 100)}%)
                </span>
              </div>
              <input 
                type="range" 
                min="0" 
                max="${roof}" 
                step="50" 
                value="${this.interventions.green_roof_m2}" 
                oninput="window.ScenarioStudioView.onSliderChange('green_roof_m2', parseFloat(this.value))"
                class="w-full accent-teal-600 cursor-pointer">
              <div class="flex justify-between text-[10px] text-slate-400">
                <span>0 m²</span>
                <span>Max Roof: ${roof} m²</span>
              </div>
            </div>

            <!-- Slider 3: Permeable Pavement -->
            <div class="space-y-1.5">
              <div class="flex justify-between items-center text-xs">
                <label class="font-bold text-slate-700">🧱 Permeable Pavement (m²)</label>
                <span id="studio-val-perm" class="font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                  ${this.interventions.permeable_pavement_m2} m² (${Math.round((this.interventions.permeable_pavement_m2 / concrete) * 100)}%)
                </span>
              </div>
              <input 
                type="range" 
                min="0" 
                max="${concrete}" 
                step="50" 
                value="${this.interventions.permeable_pavement_m2}" 
                oninput="window.ScenarioStudioView.onSliderChange('permeable_pavement_m2', parseFloat(this.value))"
                class="w-full accent-blue-600 cursor-pointer">
              <div class="flex justify-between text-[10px] text-slate-400">
                <span>0 m²</span>
                <span>Max Concrete: ${concrete} m²</span>
              </div>
            </div>

            <!-- Slider 4: Rainwater Storage -->
            <div class="space-y-1.5">
              <div class="flex justify-between items-center text-xs">
                <label class="font-bold text-slate-700">💧 Rainwater Storage Tank (L)</label>
                <span id="studio-val-rwh" class="font-bold text-sky-700 bg-sky-50 px-2 py-0.5 rounded border border-sky-200">
                  ${(this.interventions.rwh_tank_capacity_l / 1000).toFixed(0)} kL
                </span>
              </div>
              <input 
                type="range" 
                min="0" 
                max="200000" 
                step="5000" 
                value="${this.interventions.rwh_tank_capacity_l}" 
                oninput="window.ScenarioStudioView.onSliderChange('rwh_tank_capacity_l', parseFloat(this.value))"
                class="w-full accent-sky-600 cursor-pointer">
              <div class="flex justify-between text-[10px] text-slate-400">
                <span>0 L</span>
                <span>200,000 L</span>
              </div>
            </div>

            <!-- Slider 5: Solar PV Area -->
            <div class="space-y-1.5">
              <div class="flex justify-between items-center text-xs">
                <label class="font-bold text-slate-700">☀️ Rooftop Solar Array (m²)</label>
                <span id="studio-val-solar" class="font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                  ${this.interventions.solar_pv_area_m2} m² (~${Math.round(this.interventions.solar_pv_area_m2 * 0.18)} kWp)
                </span>
              </div>
              <input 
                type="range" 
                min="0" 
                max="${roof}" 
                step="50" 
                value="${this.interventions.solar_pv_area_m2}" 
                oninput="window.ScenarioStudioView.onSliderChange('solar_pv_area_m2', parseFloat(this.value))"
                class="w-full accent-amber-500 cursor-pointer">
              <div class="flex justify-between text-[10px] text-slate-400">
                <span>0 m²</span>
                <span>Max Roof: ${roof} m²</span>
              </div>
            </div>

            <!-- Real-Time Score Gauge Card -->
            <div class="bg-gradient-to-br from-emerald-800 to-teal-900 text-white p-4 rounded-xl shadow-inner flex items-center justify-between">
              <div>
                <span class="text-[10px] font-bold uppercase tracking-wider text-emerald-300">Simulated Score</span>
                <div id="studio-tier" class="text-xs text-emerald-100 font-medium">${calculations.score.tier}</div>
                <div class="text-[10px] text-emerald-200/80 mt-1">Runoff Reduction: <strong id="studio-runoff-pct">${calculations.runoff.impact_summary.runoff_reduction_pct}%</strong></div>
              </div>
              <div id="studio-score" class="w-14 h-14 rounded-full border-4 border-amber-400 bg-white/10 flex items-center justify-center text-2xl font-black text-amber-300">
                ${calculations.score.composite_score}
              </div>
            </div>
          </div>

          <!-- Right: Live Tri-State Comparative View (7 cols) -->
          <div class="lg:col-span-7 space-y-5">
            <!-- 3 Side-by-Side Compact State Cards -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
              <!-- State 1 -->
              <div class="bg-white rounded-xl p-4 border border-slate-300 shadow-sm space-y-2 text-xs">
                <div class="font-bold text-slate-700 border-b pb-1">1. Pre-Development</div>
                <div class="flex justify-between text-slate-500">
                  <span>Green Area:</span>
                  <span class="font-semibold text-slate-800">${project.vegetation.existing_green_area} m²</span>
                </div>
                <div class="flex justify-between text-slate-500">
                  <span>Trees:</span>
                  <span class="font-semibold text-slate-800">${project.vegetation.existing_tree_count} mature</span>
                </div>
                <div class="flex justify-between text-slate-500">
                  <span>Runoff Q:</span>
                  <span class="font-semibold text-slate-800">${calculations.runoff.pre_development.peak_runoff_m3_hr} m³/h</span>
                </div>
                <div class="flex justify-between text-slate-500 pt-1 border-t">
                  <span>Score:</span>
                  <span class="font-bold text-slate-700">58 / 100</span>
                </div>
              </div>

              <!-- State 2 -->
              <div class="bg-rose-50/50 rounded-xl p-4 border border-rose-200 shadow-sm space-y-2 text-xs">
                <div class="font-bold text-rose-800 border-b border-rose-200 pb-1">2. Proposed (Unmitigated)</div>
                <div class="flex justify-between text-rose-700">
                  <span>Green Area:</span>
                  <span class="font-semibold">${Math.max(0, project.vegetation.existing_green_area - (project.site.built_up_area * 0.5))} m²</span>
                </div>
                <div class="flex justify-between text-rose-700">
                  <span>Trees:</span>
                  <span class="font-semibold">-${project.vegetation.trees_removed} felled</span>
                </div>
                <div class="flex justify-between text-rose-700">
                  <span>Runoff Q:</span>
                  <span class="font-semibold">${calculations.runoff.proposed_development.peak_runoff_m3_hr} m³/h</span>
                </div>
                <div class="flex justify-between text-rose-800 pt-1 border-t border-rose-200">
                  <span>Score:</span>
                  <span class="font-bold text-rose-700">34 / 100</span>
                </div>
              </div>

              <!-- State 3 (Reactive with Sliders!) -->
              <div class="bg-emerald-50/60 rounded-xl p-4 border-2 border-emerald-500 shadow-sm space-y-2 text-xs">
                <div class="font-bold text-emerald-900 border-b border-emerald-300 pb-1 flex justify-between items-center">
                  <span>3. Green Interventions</span>
                  <span class="text-[9px] font-bold text-emerald-700 bg-white px-1.5 py-0.2 rounded border">Live</span>
                </div>
                <div class="flex justify-between text-emerald-900">
                  <span>Trees:</span>
                  <span id="st3-trees" class="font-bold">+${this.interventions.trees_planted} Planted</span>
                </div>
                <div class="flex justify-between text-emerald-900">
                  <span>Green Roof:</span>
                  <span id="st3-roof" class="font-bold">${this.interventions.green_roof_m2} m²</span>
                </div>
                <div class="flex justify-between text-emerald-900">
                  <span>Runoff Q:</span>
                  <span id="st3-q" class="font-bold text-emerald-700">${calculations.runoff.with_green_infrastructure.peak_runoff_m3_hr} m³/h</span>
                </div>
                <div class="flex justify-between text-emerald-900 pt-1 border-t border-emerald-300">
                  <span>Score:</span>
                  <span id="st3-score" class="font-black text-emerald-700">${calculations.score.composite_score} / 100</span>
                </div>
              </div>
            </div>

            <!-- Live Comparative Chart -->
            <div class="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-3">
              <div class="flex items-center justify-between">
                <h4 class="text-xs font-bold text-slate-800 uppercase tracking-wider">Peak Stormwater Runoff (Q in m³/hr)</h4>
                <span class="text-[11px] text-emerald-700 font-semibold">Lower peak is better</span>
              </div>
              <div class="relative h-56">
                <canvas id="chart-studio-runoff"></canvas>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;

    setTimeout(() => {
      this.initChart(calculations);
    }, 100);
  },

  onSliderChange(key, value) {
    this.interventions[key] = value;

    if (key === 'trees_planted') {
      document.getElementById("studio-val-trees").innerText = `${value} Trees`;
    } else if (key === 'green_roof_m2') {
      const roof = window.App.currentProject.site.roof_area;
      document.getElementById("studio-val-roof").innerText = `${value} m² (${Math.round((value/roof)*100)}%)`;
    } else if (key === 'permeable_pavement_m2') {
      const paved = window.App.currentProject.surfaces.concrete_area;
      document.getElementById("studio-val-perm").innerText = `${value} m² (${Math.round((value/paved)*100)}%)`;
    } else if (key === 'rwh_tank_capacity_l') {
      document.getElementById("studio-val-rwh").innerText = `${(value/1000).toFixed(0)} kL`;
    } else if (key === 'solar_pv_area_m2') {
      document.getElementById("studio-val-solar").innerText = `${value} m² (~${Math.round(value*0.18)} kWp)`;
    }

    this.recalculate();
  },

  recalculate() {
    const projCopy = JSON.parse(JSON.stringify(window.App.currentProject));
    projCopy.interventions = { ...this.interventions };

    const newCalcs = window.EnvironmentalCalculator.calculateOverallEnvironmentalIndicators(projCopy, window.App.environmentalData);

    const sc = newCalcs.score;
    const simScoreEl = document.getElementById("studio-score");
    if (simScoreEl) {
      simScoreEl.innerText = sc.composite_score;
      document.getElementById("studio-tier").innerText = sc.tier;
      document.getElementById("studio-runoff-pct").innerText = `${newCalcs.runoff.impact_summary.runoff_reduction_pct}%`;

      document.getElementById("st3-trees").innerText = `+${this.interventions.trees_planted} Planted`;
      document.getElementById("st3-roof").innerText = `${this.interventions.green_roof_m2} m²`;
      document.getElementById("st3-q").innerText = `${newCalcs.runoff.with_green_infrastructure.peak_runoff_m3_hr} m³/h`;
      document.getElementById("st3-score").innerText = `${sc.composite_score} / 100`;

      // Update Chart dynamically
      if (this.charts.runoff) {
        this.charts.runoff.data.datasets[0].data = [
          newCalcs.runoff.pre_development.peak_runoff_m3_hr,
          newCalcs.runoff.proposed_development.peak_runoff_m3_hr,
          newCalcs.runoff.with_green_infrastructure.peak_runoff_m3_hr
        ];
        this.charts.runoff.update();
      }
    }
  },

  resetToRecommended() {
    const recs = window.App.recommendations.recovery_summary;
    this.interventions = {
      trees_planted: recs.trees_to_plant,
      green_roof_m2: recs.green_roof_area_m2,
      permeable_pavement_m2: recs.permeable_pavement_m2,
      rwh_tank_capacity_l: recs.rwh_capacity_litres,
      solar_pv_area_m2: recs.solar_pv_area_m2
    };
    this.render(window.App.currentProject, window.App.calculations, window.App.environmentalData);
  },

  applyToPlan() {
    window.App.currentProject.interventions = { ...this.interventions };
    window.App.recalculateProject();
    alert("Scenario interventions saved to the project plan!");
    window.App.switchView("dashboard");
  },

  initChart(calculations) {
    if (!window.Chart) return;
    const ctx = document.getElementById("chart-studio-runoff");
    if (!ctx) return;

    if (this.charts.runoff) this.charts.runoff.destroy();

    this.charts.runoff = new window.Chart(ctx, {
      type: "bar",
      data: {
        labels: ["Pre-Development (Natural)", "Proposed (Hardscape)", "With Green Interventions"],
        datasets: [{
          data: [
            calculations.runoff.pre_development.peak_runoff_m3_hr,
            calculations.runoff.proposed_development.peak_runoff_m3_hr,
            calculations.runoff.with_green_infrastructure.peak_runoff_m3_hr
          ],
          backgroundColor: ["#64748b", "#f43f5e", "#10b981"],
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: { beginAtZero: true, grid: { color: "#f8fafc" }, title: { display: true, text: "Peak Runoff (m³/hr)" } }
        }
      }
    });
  }
};
