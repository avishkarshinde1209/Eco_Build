/**
 * EcoBuild Smart - Consolidated Technical Analysis Studio
 * Unifies Stormwater (Rational Method), Green Infrastructure,
 * Rooftop Solar PV, and Urban Biodiversity into a clean, tabbed workspace.
 */

window.TechnicalAnalysisView = {
  activeSubTab: "stormwater", // "stormwater", "greeninfra", "energy", "biodiversity"

  setSubTab(tab) {
    this.activeSubTab = tab;
    this.renderSubTabContent();
    this.updateTabButtons();
  },

  render(project, calculations, environmentalData) {
    const container = document.getElementById("technical-view");
    if (!container) return;

    container.innerHTML = `
      <div class="space-y-6">
        <!-- Studio Header -->
        <div class="bg-white rounded-xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-300">
              🔬 Multi-Domain Engineering Analysis
            </span>
            <h1 class="text-2xl font-bold text-slate-800 tracking-tight mt-1">Technical Domain Studio</h1>
            <p class="text-xs text-slate-500 mt-0.5">
              Deep academic calculations for hydrology, nature-based green infrastructure, solar PV yields, and native ecology.
            </p>
          </div>

          <!-- Studio Navigation Pill Tabs -->
          <div class="flex items-center gap-1 bg-slate-100 p-1.5 rounded-xl border border-slate-200 text-xs font-bold overflow-x-auto">
            <button id="tech-btn-stormwater" onclick="window.TechnicalAnalysisView.setSubTab('stormwater')" class="px-3.5 py-1.5 rounded-lg transition">
              🌧️ Stormwater
            </button>
            <button id="tech-btn-greeninfra" onclick="window.TechnicalAnalysisView.setSubTab('greeninfra')" class="px-3.5 py-1.5 rounded-lg transition">
              🌿 Green Infra
            </button>
            <button id="tech-btn-energy" onclick="window.TechnicalAnalysisView.setSubTab('energy')" class="px-3.5 py-1.5 rounded-lg transition">
              ☀️ Solar PV
            </button>
            <button id="tech-btn-biodiversity" onclick="window.TechnicalAnalysisView.setSubTab('biodiversity')" class="px-3.5 py-1.5 rounded-lg transition">
              🦋 Biodiversity
            </button>
          </div>
        </div>

        <!-- Dynamic Sub-Tab Content Shell -->
        <div id="technical-subtab-container" class="space-y-6"></div>
      </div>
    `;

    this.updateTabButtons();
    this.renderSubTabContent();
  },

  updateTabButtons() {
    const tabs = ["stormwater", "greeninfra", "energy", "biodiversity"];
    tabs.forEach(t => {
      const btn = document.getElementById(`tech-btn-${t}`);
      if (!btn) return;
      if (t === this.activeSubTab) {
        btn.className = "px-3.5 py-1.5 rounded-lg transition bg-white text-emerald-800 shadow-sm font-bold border border-slate-200";
      } else {
        btn.className = "px-3.5 py-1.5 rounded-lg transition text-slate-600 hover:text-slate-900 font-semibold";
      }
    });
  },

  renderSubTabContent() {
    const subContainer = document.getElementById("technical-subtab-container");
    if (!subContainer) return;

    // Delegate to existing dedicated sub-views within the unified container
    subContainer.id = `${this.activeSubTab}-view`;

    const proj = window.App.currentProject;
    const calc = window.App.calculations;
    const env = window.App.environmentalData;

    switch (this.activeSubTab) {
      case "stormwater":
        window.StormwaterView.render(proj, calc, env);
        break;
      case "greeninfra":
        window.GreenInfraView.render(proj, calc, env);
        break;
      case "energy":
        window.EnergyView.render(proj, calc, env);
        break;
      case "biodiversity":
        window.BiodiversityView.render(proj, calc, env);
        break;
    }
  }
};
