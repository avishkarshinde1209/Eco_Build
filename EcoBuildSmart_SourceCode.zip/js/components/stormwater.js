/**
 * EcoBuild Smart - Stormwater & Hydrological Modeling View
 * Provides deep academic and engineering analysis of the Rational Method:
 * Q = C * I * A, runoff coefficients, hydrograph curves, and infiltration loss.
 */

window.StormwaterView = {
  render(project, calculations, environmentalData) {
    const container = document.getElementById("stormwater-view");
    if (!container) return;

    const r = calculations.runoff;
    const envRain = environmentalData?.rainfall;
    const coeffs = window.ECO_CONFIG.RUNOFF_COEFFICIENTS;

    container.innerHTML = `
      <div class="space-y-6">
        <!-- Header -->
        <div class="bg-white rounded-xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800 border border-blue-300">
              🌧️ Hydrological Runoff Modeling
            </span>
            <h1 class="text-2xl font-bold text-slate-800 tracking-tight mt-1">Stormwater & Watershed Impact</h1>
            <p class="text-xs text-slate-500 mt-0.5">
              Evaluation of peak surface runoff rates and groundwater infiltration using the classical Rational Formula.
            </p>
          </div>
          <button onclick="window.ExplainModal.open('runoff_deficit')" class="px-3.5 py-2 text-xs font-semibold rounded-lg bg-blue-50 text-blue-700 border border-blue-200 hover:bg-blue-100 flex items-center gap-1.5">
            <span>ℹ️</span> Inspect Rational Method Theory
          </button>
        </div>

        <!-- Formula Explainer Banner -->
        <div class="bg-gradient-to-r from-blue-900 to-indigo-900 text-white rounded-xl p-6 shadow-sm">
          <div class="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div class="space-y-2 max-w-2xl">
              <div class="text-xs font-bold text-blue-300 uppercase tracking-wider">Governing Hydrological Formula</div>
              <div class="text-3xl font-mono font-bold tracking-wider text-amber-300">Q = C × I × A</div>
              <p class="text-xs text-blue-100 leading-relaxed">
                Where <strong>Q</strong> is Peak Runoff Rate (m³/hr), <strong>C</strong> is the dimensionless composite surface runoff coefficient, <strong>I</strong> is the design rainfall intensity (${envRain?.peak_intensity_mm_hr || 35.0} mm/hr), and <strong>A</strong> is the site catchment area (${project.site.plot_area} m²).
              </p>
            </div>
            <div class="bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/15 text-xs space-y-1">
              <div class="font-bold text-amber-200">Site Metric Summary:</div>
              <div>• Catchment Area: <strong>${project.site.plot_area} m²</strong></div>
              <div>• Baseline Pre-Dev C: <strong>${r.pre_development.composite_c}</strong></div>
              <div>• Proposed Post-Dev C: <strong>${r.proposed_development.composite_c}</strong></div>
              <div>• Green Interventions C: <strong>${r.with_green_infrastructure.composite_c}</strong></div>
            </div>
          </div>
        </div>

        <!-- Runoff Matrix & Scenario Comparison -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div class="bg-white rounded-xl p-5 border border-slate-200 shadow-sm space-y-3">
            <span class="text-xs font-bold text-slate-500 uppercase tracking-wider block">Pre-Development (Natural)</span>
            <div class="text-3xl font-bold text-slate-800">${r.pre_development.peak_runoff_m3_hr} <span class="text-sm font-normal text-slate-500">m³/hr</span></div>
            <p class="text-xs text-slate-600">
              High infiltration through ${project.vegetation.existing_green_area} m² of natural soil and grass cover. Annual runoff: <strong>${(r.pre_development.annual_runoff_litres / 1000).toLocaleString()} m³</strong>.
            </p>
          </div>

          <div class="bg-white rounded-xl p-5 border border-rose-300 shadow-sm space-y-3 bg-rose-50/20">
            <span class="text-xs font-bold text-rose-700 uppercase tracking-wider block">Proposed (Hardscape Sprawl)</span>
            <div class="text-3xl font-bold text-rose-700">${r.proposed_development.peak_runoff_m3_hr} <span class="text-sm font-normal text-rose-500">m³/hr</span></div>
            <p class="text-xs text-rose-800">
              Runoff spikes by <strong>+${r.impact_summary.peak_runoff_increase_pct}%</strong> due to impermeable RCC slabs and concrete paving. Generates <strong>+${(r.impact_summary.annual_additional_runoff_litres / 1000).toLocaleString()} m³</strong> excess stormwater annually.
            </p>
          </div>

          <div class="bg-white rounded-xl p-5 border border-emerald-300 shadow-sm space-y-3 bg-emerald-50/20">
            <span class="text-xs font-bold text-emerald-700 uppercase tracking-wider block">Mitigated (Green Infrastructure)</span>
            <div class="text-3xl font-bold text-emerald-700">${r.with_green_infrastructure.peak_runoff_m3_hr} <span class="text-sm font-normal text-emerald-500">m³/hr</span></div>
            <p class="text-xs text-emerald-800">
              Permeable pavers and extensive green roofs retain water at source, cutting peak runoff by <strong>${r.impact_summary.runoff_reduction_pct}%</strong>.
            </p>
          </div>
        </div>

        <!-- Runoff Coefficients Reference Table -->
        <div class="bg-white rounded-xl p-6 border border-slate-200 shadow-sm space-y-4">
          <h3 class="text-sm font-bold text-slate-800">Surface Runoff Coefficients (C) Specification Table</h3>
          <div class="overflow-x-auto">
            <table class="w-full text-xs text-left">
              <thead class="bg-slate-50 text-slate-700 font-semibold border-b">
                <tr>
                  <th class="p-3">Surface Category</th>
                  <th class="p-3">Design Value (C)</th>
                  <th class="p-3">Empirical Range</th>
                  <th class="p-3">Hydrological Behavior</th>
                  <th class="p-3">Standard Reference</th>
                </tr>
              </thead>
              <tbody class="divide-y text-slate-600">
                ${Object.keys(coeffs).map(key => {
                  const item = coeffs[key];
                  return `
                    <tr class="hover:bg-slate-50/60">
                      <td class="p-3 font-semibold text-slate-800">${item.label}</td>
                      <td class="p-3 font-mono font-bold ${item.value > 0.6 ? 'text-rose-600' : 'text-emerald-700'}">${item.value}</td>
                      <td class="p-3">${item.range}</td>
                      <td class="p-3">${item.value >= 0.8 ? 'Impervious (High flash flooding risk)' : item.value >= 0.4 ? 'Semi-pervious (Moderate absorption)' : 'High Infiltration (Bioretention)'}</td>
                      <td class="p-3 text-slate-400">${item.source}</td>
                    </tr>
                  `;
                }).join("")}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  }
};
